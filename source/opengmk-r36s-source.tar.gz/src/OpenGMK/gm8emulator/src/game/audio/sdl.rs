use super::mixer::{Mixer, MixerHandle};
use udon::source::{ChannelCount, SampleRate, Source};

use std::{
    ffi::{c_char, c_int, c_void},
    ptr,
    sync::{
        atomic::{AtomicU32, Ordering},
        Arc, Mutex,
    },
};

const SDL_INIT_AUDIO: u32 = 0x0000_0010;
const AUDIO_F32SYS: u16 = 0x8120;

#[repr(C)]
struct SdlAudioSpec {
    freq: c_int,
    format: u16,
    channels: u8,
    silence: u8,
    samples: u16,
    padding: u16,
    size: u32,
    callback: Option<extern "C" fn(*mut c_void, *mut u8, c_int)>,
    userdata: *mut c_void,
}

#[link(name = "SDL2")]
extern "C" {
    fn SDL_InitSubSystem(flags: u32) -> c_int;
    fn SDL_GetError() -> *const c_char;
    fn SDL_OpenAudioDevice(
        device: *const c_char,
        iscapture: c_int,
        desired: *const SdlAudioSpec,
        obtained: *mut SdlAudioSpec,
        allowed_changes: c_int,
    ) -> u32;
    fn SDL_CloseAudioDevice(device: u32);
    fn SDL_PauseAudioDevice(device: u32, pause_on: c_int);
}

static MIXER: Mutex<Option<Mixer>> = Mutex::new(None);
static DEVICE: AtomicU32 = AtomicU32::new(0);

extern "C" fn callback(_userdata: *mut c_void, stream: *mut u8, len: c_int) {
    if stream.is_null() || len <= 0 {
        return
    }
    let count = len as usize / std::mem::size_of::<f32>();
    let buffer = unsafe { std::slice::from_raw_parts_mut(stream.cast::<f32>(), count) };
    match MIXER.try_lock() {
        Ok(mut guard) => match guard.as_mut() {
            Some(mixer) => {
                let written = mixer.write_samples(buffer);
                buffer[written..].iter_mut().for_each(|sample| *sample = 0.0);
            },
            None => buffer.iter_mut().for_each(|sample| *sample = 0.0),
        },
        Err(_) => buffer.iter_mut().for_each(|sample| *sample = 0.0),
    }
}

fn error() -> String {
    unsafe {
        let ptr = SDL_GetError();
        if ptr.is_null() {
            "error de SDL desconocido".to_string()
        } else {
            std::ffi::CStr::from_ptr(ptr).to_string_lossy().into_owned()
        }
    }
}

pub fn open(global_volume: Arc<AtomicU32>) -> Result<(u32, ChannelCount, SampleRate, MixerHandle), String> {
    unsafe {
        if SDL_InitSubSystem(SDL_INIT_AUDIO) != 0 {
            return Err(error())
        }

        let desired = SdlAudioSpec {
            freq: 48000,
            format: AUDIO_F32SYS,
            channels: 2,
            silence: 0,
            samples: 1024,
            padding: 0,
            size: 0,
            callback: Some(callback),
            userdata: ptr::null_mut(),
        };
        let mut obtained = SdlAudioSpec {
            freq: 0,
            format: 0,
            channels: 0,
            silence: 0,
            samples: 0,
            padding: 0,
            size: 0,
            callback: None,
            userdata: ptr::null_mut(),
        };
        let device = SDL_OpenAudioDevice(ptr::null(), 0, &desired, &mut obtained, 0);
        if device == 0 {
            return Err(error())
        }

        let channels = ChannelCount::new(obtained.channels.max(1) as u16)
            .ok_or_else(|| "numero de canales de audio invalido".to_string())?;
        let sample_rate = SampleRate::new(obtained.freq.max(8000) as u32)
            .ok_or_else(|| "frecuencia de audio invalida".to_string())?;

        let (mixer, handle) = Mixer::new(sample_rate, channels, global_volume);
        *MIXER.lock().map_err(|_| "mutex de audio envenenado".to_string())? = Some(mixer);
        DEVICE.store(device, Ordering::Release);
        SDL_PauseAudioDevice(device, 0);

        eprintln!(
            "[sdl-audio] salida abierta: {} canales @ {} Hz",
            channels.get(),
            sample_rate.get()
        );
        Ok((device, channels, sample_rate, handle))
    }
}

pub fn set_paused(paused: bool) {
    let device = DEVICE.load(Ordering::Acquire);
    if device != 0 {
        unsafe {
            SDL_PauseAudioDevice(device, if paused { 1 } else { 0 });
        }
    }
}

pub fn close() {
    let device = DEVICE.swap(0, Ordering::AcqRel);
    if device != 0 {
        unsafe {
            SDL_CloseAudioDevice(device);
        }
    }
}
