use ramen::{connection::Connection, window::Window};

use std::{
    ffi::{c_char, c_void},
    os::raw::c_int,
    ptr,
    sync::OnceLock,
};

type EglGetCurrentDisplay = unsafe extern "C" fn() -> *mut c_void;
type EglGetCurrentSurface = unsafe extern "C" fn(which: c_int) -> *mut c_void;
type EglGetCurrentContext = unsafe extern "C" fn() -> *mut c_void;
type EglSwapBuffers = unsafe extern "C" fn(display: *mut c_void, surface: *mut c_void) -> u32;
type EglSwapInterval = unsafe extern "C" fn(display: *mut c_void, interval: c_int) -> u32;
type EglGetProcAddress = unsafe extern "C" fn(name: *const c_char) -> *const c_void;
type EglGetError = unsafe extern "C" fn() -> u32;

extern "C" {
    fn SDL_GL_GetCurrentWindow() -> *mut c_void;
    fn SDL_GL_GetCurrentContext() -> *mut c_void;
    fn SDL_GL_MakeCurrent(window: *mut c_void, context: *mut c_void) -> c_int;
    fn SDL_GL_SwapWindow(window: *mut c_void);
}

const EGL_DRAW: c_int = 0x3059;
const EGL_SUCCESS: u32 = 0x3000;
const EGL_CONTEXT_LOST: u32 = 0x300E;

unsafe impl Send for EglFns {}
unsafe impl Sync for EglFns {}

struct EglFns {
    _handle: usize,
    get_current_display: EglGetCurrentDisplay,
    get_current_surface: EglGetCurrentSurface,
    get_current_context: EglGetCurrentContext,
    swap_buffers: EglSwapBuffers,
    swap_interval: EglSwapInterval,
    get_proc_address: EglGetProcAddress,
    get_error: EglGetError,
}

static EGL_FNS: OnceLock<Result<EglFns, String>> = OnceLock::new();
static GLES_HANDLE: OnceLock<usize> = OnceLock::new();

fn load(name: &[u8]) -> *mut c_void {
    unsafe { libc::dlopen(name.as_ptr().cast(), libc::RTLD_NOW | libc::RTLD_GLOBAL) }
}

fn symbol(handle: *mut c_void, name: &[u8]) -> *mut c_void {
    unsafe {
        libc::dlerror();
        libc::dlsym(handle, name.as_ptr().cast())
    }
}

fn egl_fns() -> Result<&'static EglFns, String> {
    let result = EGL_FNS.get_or_init(|| {
        let handle = load(b"libEGL.so.1\0");
        let handle = if handle.is_null() { load(b"libEGL.so\0") } else { handle };
        if handle.is_null() {
            return Err("no se encontro libEGL.so.1 ni libEGL.so".to_string())
        }
        unsafe {
            let get_current_display = symbol(handle, b"eglGetCurrentDisplay\0");
            let get_current_surface = symbol(handle, b"eglGetCurrentSurface\0");
            let get_current_context = symbol(handle, b"eglGetCurrentContext\0");
            let swap_buffers = symbol(handle, b"eglSwapBuffers\0");
            let swap_interval = symbol(handle, b"eglSwapInterval\0");
            let get_proc_address = symbol(handle, b"eglGetProcAddress\0");
            let get_error = symbol(handle, b"eglGetError\0");
            if get_current_display.is_null()
                || get_current_surface.is_null()
                || get_current_context.is_null()
                || swap_buffers.is_null()
                || swap_interval.is_null()
                || get_proc_address.is_null()
            {
                return Err("libEGL no expone las funciones necesarias".to_string())
            }
            Ok(EglFns {
                _handle: handle as usize,
                get_current_display: std::mem::transmute(get_current_display),
                get_current_surface: std::mem::transmute(get_current_surface),
                get_current_context: std::mem::transmute(get_current_context),
                swap_buffers: std::mem::transmute(swap_buffers),
                swap_interval: std::mem::transmute(swap_interval),
                get_proc_address: std::mem::transmute(get_proc_address),
                get_error: std::mem::transmute(get_error),
            })
        }
    });
    match result {
        Ok(fns) => Ok(fns),
        Err(e) => Err(e.clone()),
    }
}

fn gles_handle() -> Result<usize, String> {
    let handle = *GLES_HANDLE.get_or_init(|| {
        let mut handle = load(b"libGLESv2.so.2\0");
        if handle.is_null() {
            handle = load(b"libGLESv2.so\0");
        }
        if handle.is_null() {
            handle = load(b"libGLESv2.so.3\0");
        }
        handle as usize
    });
    if handle == 0 {
        Err("no se encontro libGLESv2".to_string())
    } else {
        Ok(handle)
    }
}

#[derive(Clone, Copy)]
pub struct PlatformImpl {
    swap_interval: u32,
}

impl PlatformImpl {
    pub unsafe fn new(_connection: &Connection, _window: &Window) -> Result<Self, String> {
        let egl = egl_fns()?;
        let display = (egl.get_current_display)();
        let surface = (egl.get_current_surface)(EGL_DRAW);
        let context = (egl.get_current_context)();
        if display.is_null() || surface.is_null() || context.is_null() {
            return Err("SDL no ha dejado un contexto EGL/GLES activo".to_string())
        }
        Ok(Self { swap_interval: 1 })
    }

    pub unsafe fn get_function_loader() -> Result<Box<dyn FnMut(&'static str) -> *const c_void>, String> {
        let egl = egl_fns()?;
        let gles = gles_handle()? as *mut c_void;
        Ok(Box::new(move |name: &'static str| {
            let mut buf = Vec::with_capacity(name.len() + 1);
            buf.extend_from_slice(name.as_bytes());
            buf.push(0);
            let mut ptr = (egl.get_proc_address)(buf.as_ptr().cast()) as *const c_void;
            if ptr.is_null() {
                ptr = symbol(gles, &buf) as *const c_void;
            }
            if ptr.is_null() {
                ptr = symbol(ptr::null_mut(), &buf) as *const c_void;
            }
            ptr
        }))
    }

    pub unsafe fn clean_function_loader() {}

    pub unsafe fn make_current(&self) {
        // SDL owns the EGL surface and re-creates it when the game changes the window
        // size (320x180 -> 640x480). Re-bind the context to the window before drawing
        // the final blit so it lands in the surface that is actually being scanned out.
        let window = SDL_GL_GetCurrentWindow();
        let context = SDL_GL_GetCurrentContext();
        if !window.is_null() && !context.is_null() {
            let _ = SDL_GL_MakeCurrent(window, context);
        }
    }

    pub unsafe fn swap_buffers(&self) {
        let window = SDL_GL_GetCurrentWindow();
        if !window.is_null() {
            SDL_GL_SwapWindow(window);
            return;
        }
        let Ok(egl) = egl_fns() else { return };
        let display = (egl.get_current_display)();
        let surface = (egl.get_current_surface)(EGL_DRAW);
        if display.is_null() || surface.is_null() {
            eprintln!("[gl] no hay display/surface EGL actual");
            return;
        }
        if (egl.swap_buffers)(display, surface) == 0 {
            let error = (egl.get_error)();
            if error != EGL_SUCCESS {
                if error == EGL_CONTEXT_LOST {
                    eprintln!("[gl] contexto EGL perdido");
                } else {
                    eprintln!("[gl] eglSwapBuffers fallo (0x{:04X})", error);
                }
            }
        }
    }

    pub unsafe fn set_swap_interval(&self, n: u32) -> bool {
        let Ok(egl) = egl_fns() else { return false };
        let display = (egl.get_current_display)();
        if display.is_null() {
            return false;
        }
        (egl.swap_interval)(display, n as c_int) != 0
    }

    pub unsafe fn get_swap_interval(&self) -> u32 {
        self.swap_interval
    }

    pub unsafe fn wait_vsync(&self) {}
}
